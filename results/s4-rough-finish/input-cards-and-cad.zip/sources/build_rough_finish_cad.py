"""Pre-CAM native targets: filleted-prism final and rough-state oracles."""
import json
import os
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path[:0] = [str(ROOT), str(ROOT / 'step2gcode_demo/validation')]
from local_resource_limits import require_bounded_worker
from genlaw_pipeline.preparation import digest
from genlaw_pipeline.pocket_geometry import POCKET, nominal_area


def build():
    require_bounded_worker()
    import FreeCAD as App
    import Part
    out = Path(os.environ['GENLAW_ROUGH_FINISH_CAD'])
    specs = json.loads((out / 'specifications.json').read_text())
    for case in specs['cases']:
        folder = out / case['id']; folder.mkdir()
        lo, hi = [case['stock_bounds_mm'][k] for k in ('min', 'max')]
        final = case['feature']; a, b = case['radial_allowance_mm'], case['axial_allowance_mm']
        rough = {**final, 'width_mm': final['width_mm']-2*a, 'height_mm': final['height_mm']-2*a,
                 'corner_radius_mm': final['corner_radius_mm']-a, 'depth_mm': final['depth_mm']-b}
        shapes = []
        for name, f in [('target', final), ('rough-expected', rough)]:
            x, y = f['center_xy_mm']; d = f['depth_mm']; w, h, r = [f[k] for k in ('width_mm','height_mm','corner_radius_mm')]
            prism = Part.makeBox(w, h, d, App.Vector(x-w/2, y-h/2, hi[2]-d))
            edges = [e for e in prism.Edges if abs(e.BoundBox.ZLength-d)<1e-8]
            assert len(edges) == 4
            cutter = prism.makeFillet(r, edges)
            shape = Part.makeBox(*[y-x for x,y in zip(lo,hi)], App.Vector(*lo)).cut(cutter)
            volume = (hi[0]-lo[0])*(hi[1]-lo[1])*(hi[2]-lo[2])-nominal_area(f)*d
            assert shape.isValid() and len(shape.Solids)==1 and abs(shape.Volume-volume)<1e-8
            shape.exportBrep(str(folder / (name+'.brep')))
            shape.exportStep(str(folder / (name+'.step')))
            ref = {'sha256':digest(folder/(name+'.brep')), 'reference_class':POCKET, 'bounds':case['stock_bounds_mm'],
                   'features':[f], 'valid_single_solid':True, 'volume_mm3':shape.Volume,
                   'target_created_before_nc':True, 'construction':'Native prism with four vertical edge fillets; no CAM/NC input.',
                   'freecad_version':list(App.Version())}
            (folder/(name+'-reference.json')).write_text(json.dumps(ref,indent=2)+'\n')
            shapes.append(shape)
        assert shapes[0].cut(shapes[1]).Volume < 1e-8
        assert shapes[1].cut(shapes[0]).Volume > 0
    (out/'cad-generation.json').write_text(json.dumps({'status':'created_before_nc','cases':len(specs['cases']),
        'rough_oracles_are_simulation_input':False,'generator_sha256':digest(Path(__file__))})+'\n')


if __name__ == '__main__' or 'GENLAW_ROUGH_FINISH_CAD' in os.environ:
    build()
