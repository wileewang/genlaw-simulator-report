"""Freeze auditable rough/finish paper cards, CAD and independent criteria."""
import argparse
import copy
import json
from pathlib import Path
import sys
import zipfile

ROOT = Path(__file__).resolve().parents[1]; sys.path.insert(0, str(ROOT))
from genlaw_pipeline.preparation import digest
from genlaw_pipeline.run import bounded, write, FREECAD, workspace_environment


def specifications():
    feature = {'id':'P1','kind':'rounded_rectangular_pocket','axis':[0,0,1], 'center_xy_mm':[4,3],
               'width_mm':4,'height_mm':3,'corner_radius_mm':.75,'depth_mm':.75}
    variants = [('radial','侧壁留量',.2,0,[4,3]), ('axial','槽底留量',0,.2,[4,3]),
                ('combined','侧壁与槽底留量',.2,.2,[4,3]), ('shifted','偏置槽及不同余量',.15,.25,[4.5,3.2])]
    return {'schema':'genlaw.rough-finish-fixtures.v1','production_approved':False,
        'selection':'Same XYZ setup and same tool first: radial-only, axial-only, both, and distinct allowances/position.',
        'cases':[{'id':key,'name':name,'feature':{**feature,'center_xy_mm':xy},'radial_allowance_mm':a,
                  'axial_allowance_mm':b,'stock_bounds_mm':{'min':[0,0,-1.5],'max':[8,6,0]}}
                 for key,name,a,b,xy in variants]}


def paper(path, spec, card, resources):
    from html import escape
    from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, PageBreak
    from reportlab.lib.styles import ParagraphStyle
    from reportlab.pdfbase import pdfmetrics
    from reportlab.pdfbase.ttfonts import TTFont
    from reportlab.graphics.shapes import Drawing, Rect, String
    from reportlab.lib import colors
    pdfmetrics.registerFont(TTFont('RoughCJK','/usr/share/fonts/truetype/droid/DroidSansFallbackFull.ttf'))
    pdfmetrics.registerFont(TTFont('RoughLatin','/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'))
    def font(ch):
        return 'RoughLatin' if ord(ch) in pdfmetrics.getFont('RoughLatin').face.charToGlyph else 'RoughCJK'
    def mixed(text):
        return ''.join('<font name="'+font(ch)+'">'+escape(ch)+'</font>' for ch in str(text))
    style=ParagraphStyle('body',fontName='RoughCJK',fontSize=9,leading=15,wordWrap='CJK')
    title=ParagraphStyle('title',parent=style,fontSize=17,leading=24,spaceAfter=14)
    p=lambda text:Paragraph(mixed(text),style)
    story=[Paragraph(mixed('机械加工工艺卡 · 粗精工序验证'),title),p(card['id']+' / '+spec['name']),Spacer(1,10)]
    f=spec['feature']; a=spec['radial_allowance_mm']; b=spec['axial_allowance_mm']
    def table(rows, widths):
        t=Table([[p(str(x)) for x in row] for row in rows],colWidths=widths,hAlign='LEFT')
        t.setStyle(TableStyle([('GRID',(0,0),(-1,-1),.4,colors.HexColor('#94a3b8')),('VALIGN',(0,0),(-1,-1),'TOP'),
             ('BACKGROUND',(0,0),(-1,0),colors.HexColor('#e2e8f0')),('TOPPADDING',(0,0),(-1,-1),7),('BOTTOMPADDING',(0,0),(-1,-1),7)]))
        return t
    story.append(table([['项目','声明内容'],['零件 / 版次',card['id']+'；合成软件验证件'],
        ['材料 / 毛坯','6061-T6 标签；矩形毛坯 8 × 6 × 1.5 mm；不模拟材料物理'],
        ['设备 / 装夹','通用 XYZ 参考机床 / 同一装夹；实际夹具、刀柄尚未建模'],
        ['坐标基准','G54 零变换；毛坯顶面左下角 (0,0,0)，Z 向上'],
        ['制造要求','公差、粗糙度与现场参数待工艺师傅审核；软件检查条件单列'],
        ['原卡来源','开发者编制；不是客户生产工艺卡的转录，也未获生产批准']],[85,420]))
    story += [Spacer(1,16),p('目标 CAD / 粗加工预期轮廓（俯视示意；单位 mm）')]
    d=Drawing(505,205); scale=25; ox=20; oy=25
    d.add(Rect(ox,oy,8*scale,6*scale,fillColor=None,strokeColor=colors.HexColor('#334155')))
    x,y=f['center_xy_mm']; w,h,r=[f[k] for k in ('width_mm','height_mm','corner_radius_mm')]
    for offset,color in [(0,'#2563eb'),(a,'#ea580c')]:
        d.add(Rect(ox+(x-w/2+offset)*scale,oy+(y-h/2+offset)*scale,(w-2*offset)*scale,(h-2*offset)*scale,
                   rx=(r-offset)*scale,ry=(r-offset)*scale,fillColor=None,strokeColor=colors.HexColor(color),strokeWidth=1.4))
    for j,s in enumerate([f'P1：{w:g} × {h:g}，R{r:g}',f'槽心：({x:g}, {y:g})',f'最终深度：{f["depth_mm"]:g}',f'粗加工深度：{f["depth_mm"]-b:g}',f'侧壁留量：{a:g}',f'槽底留量：{b:g}']):
        xx=260
        for ch in s:
            d.add(String(xx,170-j*25,ch,fontName=font(ch),fontSize=10));xx+=pdfmetrics.stringWidth(ch,font(ch),10)
    story += [d,p('蓝线为最终轮廓，橙线为粗加工轮廓；仅槽底留量时两线重合。阶段预期 CAD 仅用于验收，不能作为仿真来料。'),PageBreak(),Paragraph(mixed('工序 / 工步'),title)]
    rows=[['工序 / 工步','内容与验收','设备 / 刀具']]
    for op in card['operations']:
        for step in op['steps']:rows.append([op['id']+' / '+step['id'],step['text'],'XYZ / T1' if step.get('type')=='pocket_milling' else '按实际资料确认'])
    story += [table(rows,[92,320,93]),Spacer(1,14),p('编制：开发者合成验证；校对：同一结构化来源与纸卡逐项核对；工艺审核 / 批准：待定。保留来料、装夹、去毛刺与最终检验等未覆盖工序，不将选定加工段通过视为整卡通过。'),PageBreak(),Paragraph(mixed('软件执行附件 / 阶段检验'),title)]
    story += [table([['项目','明确值 / 验收范围'],['刀具','T1：φ1 可中心切削平底铣刀；有效刃长 5 mm，总长 20 mm；粗精同刀'],
        ['切削参数','S3000 rpm；水平 F120、下刀 F60 mm/min；每层 ≤ 0.25 mm，步距 50%'],
        ['CAM / 安全高度','FreeCAD PocketShape；Offset / Climb / Center；层间退刀；安全 Z2、清空 Z3'],
        ['粗加工','侧壁法向留量 '+str(a)+' mm；槽底轴向留量 '+str(b)+' mm；明确独立工步'],
        ['精加工','相同最终 CAD、同一剩料；径向与轴向余量均为零；第一版重复清空路径可含空走刀'],
        ['中间检验','与 NC 前存档的粗加工预期 CAD 比较，检查轮廓、深度、底面和保留材料'],
        ['最终检验','与原始成品 CAD 比较，报告 IoU、轮廓偏差、深度与底厚；另核对工序顺序'],
        ['数值条件','网格 0.025 mm；轮廓/深度/平面软件阈值 0.1 mm；数值保护带 0.05 mm，非标定误差界'],
        ['错误对照','漏精加工、错误余量、先精后粗、精加工过切；保留相同原 CAD 和验收条件'],
        ['未覆盖','实际装夹与碰撞、切削载荷、刀具磨损、材料物理、粗糙度与生产放行']],[85,420])]
    def footer(c,doc):
        x=44
        for ch in card['id']+' · 第 '+str(doc.page)+' 页 · 软件验证，非现场加工批准':
            c.setFont(font(ch),8);c.drawString(x,30,ch);x+=pdfmetrics.stringWidth(ch,font(ch),8)
    SimpleDocTemplate(str(path),leftMargin=44,rightMargin=44,topMargin=40,bottomMargin=48).build(story,onFirstPage=footer,onLaterPages=footer)


def build(out,cad_from=None):
    out=out.resolve()
    if not out.is_relative_to(ROOT):raise ValueError('Keep all artifacts in project')
    out.mkdir(parents=True,exist_ok=False)
    specs=specifications(); write(out/'specifications.json',specs)
    if cad_from:
        old=json.loads((cad_from/'manifest.json').read_text())
        if json.loads((cad_from/'specifications.json').read_text())!=specs:raise ValueError('CAD reuse requires identical specifications')
        for case in specs['cases']:
            (out/case['id']).mkdir()
            for base in ('target','rough-expected'):
                for suffix in ('.brep','.step','-reference.json'):
                    relative=case['id']+'/'+base+suffix;source=cad_from/relative
                    if digest(source)!=old['files'][relative]['sha256']:raise ValueError('Original CAD changed')
                    (out/relative).write_bytes(source.read_bytes())
        write(out/'cad-generation.json',{'status':'reused_frozen_pre_cam_geometry','source_manifest_sha256':digest(cad_from/'manifest.json'),
            'source':str(cad_from),'target_created_before_nc':True,'rough_oracles_are_simulation_input':False})
    else:
        env=workspace_environment(); env.update(GENLAW_ROUGH_FINISH_CAD=str(out),QT_QPA_PLATFORM='offscreen')
        bounded(out,'generate-cad',[FREECAD,'freecadcmd',ROOT/'tools/build_rough_finish_cad.py'],env)
    base=ROOT/'validation/feature-inputs/S3-POCKET-20261029-r2/baseline'
    for spec in specs['cases']:
        folder=out/spec['id']; f=spec['feature']; sha=digest(folder/'target.brep')
        card=json.loads((base/'process-plan.json').read_text()); card.update(id='S4-ROUGH-FINISH-'+spec['id']+'-'+out.name.rsplit('-',1)[-1],cad_sha256=sha)
        card['transcription']={'status':'generated_from_same_authoring_source','reviewer_role':'developer_synthetic_author','production_review':False}
        rough=card['operations'][1]['steps'][1]
        rough.update(stage='rough',preset_id='P-ROUGH',allowance_mm={'radial':spec['radial_allowance_mm'],'axial':spec['axial_allowance_mm']},
            constraints={k:f[k] for k in ('width_mm','height_mm','corner_radius_mm','depth_mm')})
        rough['constraints'].update(bottom_shape='flat',tool_id='T1')
        rough['text']=f"粗铣 P1；最终 {f['width_mm']:g} × {f['height_mm']:g}、R{f['corner_radius_mm']:g}、深 {f['depth_mm']:g} mm。每侧法向留 {spec['radial_allowance_mm']:g} mm，底部留 {spec['axial_allowance_mm']:g} mm。粗后核对余量和保留面。"
        finish=copy.deepcopy(rough);finish.update(id='OP10.3',stage='finish',preset_id='P-FINISH',depends_on=['OP10.2'],allowance_mm={'radial':0,'axial':0},
            text='同一装夹、同一 T1，沿用粗加工剩料精铣 P1 至原 CAD；侧壁与底部余量均为零，核对最终轮廓、槽深与底厚。')
        finish['source']['location']='工序 / 工步 OP10.3'
        card['operations'][1]['steps'].append(finish);write(folder/'process-plan.json',card)
        resources=json.loads((base/'resources-software-reference.json').read_text());resources['id']=card['id']+'-RESOURCES'
        preset=resources['cutting_presets'][0];presets=[]
        for stage in (rough,finish):
            p=copy.deepcopy(preset);p.update(id=stage['preset_id'],radial_allowance_mm=stage['allowance_mm']['radial'],axial_allowance_mm=stage['allowance_mm']['axial']);presets.append(p)
        resources['cutting_presets']=presets;write(folder/'resources.json',resources)
        req=json.loads((base/'requirements.json').read_text());req['cad_sha256']=sha
        for item in req['items']:
            if item['kind']=='profile_xy':item['nominal']={k:f[k] for k in ('center_xy_mm','width_mm','height_mm','corner_radius_mm')}
            if item['kind']=='pocket_depth':item['nominal']=f['depth_mm']
        write(folder/'requirements.json',req)
        common={'schema':'genlaw.numeric-acceptance.v1','units':'mm','scope':'software_regression','basis':'Frozen before NC; synthetic numerical criteria, not approved manufacturing tolerances.'}
        stages={}
        for name,refname in [('rough','rough-expected'),('finish','target')]:
            ref=json.loads((folder/(refname+'-reference.json')).read_text());d=ref['features'][0]['depth_mm']
            stages[name]={'cad_sha256':ref['sha256'],'profile_xy':{**common,'method':'sampled_boundary_distance','max_deviation_mm':.1},
                'pocket_depth':{**common,'method':'sampled_floor_depth','min_mm':d-.1,'max_mm':d+.1},
                'floor_geometry':{**common,'method':'sampled_flat_floor','max_flatness_mm':.1,'min_remaining_floor_mm':.1}}
        write(folder/'stage-policy.json',{'schema':'genlaw.rough-finish-policy.v1','production_approved':False,'stages':stages,
              'order':['OP10.2','OP10.3'],'geometry_pass_does_not_prove_process_order':True})
        paper(folder/'process-card.pdf',spec,card,resources)
        names={'process_plan':'process-plan.json','cad':'target.brep','display_cad':'target.step','native_reference':'target-reference.json',
               'rough_cad':'rough-expected.brep','rough_display_cad':'rough-expected.step','rough_reference':'rough-expected-reference.json',
               'requirements':'requirements.json','resources':'resources.json','paper_card':'process-card.pdf','stage_policy':'stage-policy.json'}
        entry={'schema':'genlaw.rough-finish-input.v1','id':card['id'],'mode':'software_geometry_reference','capability':'rounded_pocket_rough_finish_xy',
               'source_documents':{'CARD':'paper_card'},'scope':{**json.loads((base/'input.json').read_text())['scope'],'selected_steps':['OP10.2','OP10.3']},
               'files':{key:{'path':name,'sha256':digest(folder/name)} for key,name in names.items()}}
        write(folder/'input.json',entry)
    sources=out/'sources';sources.mkdir()
    for name in ('build_rough_finish_inputs.py','build_rough_finish_cad.py'):
        (sources/name).write_bytes((ROOT/'tools'/name).read_bytes())
    write(out/'manifest.json',{'id':out.name,'status':'inputs_archived_before_cam','previous_goal_turn':'progress',
        'production_approved':False,'whole_process_card_passed':False,
        'files':{str(p.relative_to(out)):{'bytes':p.stat().st_size,'sha256':digest(p)} for p in sorted(out.rglob('*')) if p.is_file()}})
    with zipfile.ZipFile(out.with_suffix('.zip'),'x',compression=zipfile.ZIP_DEFLATED) as z:
        for p in sorted(out.rglob('*')):
            if p.is_file():z.write(p,str(p.relative_to(out)))
    print(json.dumps({'status':'inputs_archived_before_cam','cases':4,'output':str(out),'manifest_sha256':digest(out/'manifest.json')}))


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--output',type=Path,required=True);parser.add_argument('--cad-from',type=Path)
    args=parser.parse_args();build(args.output,args.cad_from)
