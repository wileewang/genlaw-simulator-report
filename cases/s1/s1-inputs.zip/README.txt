GenLaw S1 software test input. Open simulation.camotics with reference.nc in the same folder.
process-card.json records the executed fixed script parameters; generic JSON ingestion is pending.
The fixture/material physics and real-machine compatibility are not qualified.
